/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/Lab 8/Booth_Multiplication.v";
static unsigned int ng1[] = {0U, 0U};
static int ng2[] = {7, 0};
static int ng3[] = {4, 0};
static int ng4[] = {3, 0};
static int ng5[] = {0, 0};
static unsigned int ng6[] = {2U, 0U};
static unsigned int ng7[] = {1U, 0U};
static int ng8[] = {1, 0};



static void Always_29_0(char *t0)
{
    char t6[8];
    char t7[8];
    char t8[8];
    char t35[8];
    char t36[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    unsigned int t15;
    int t16;
    char *t17;
    unsigned int t18;
    int t19;
    int t20;
    char *t21;
    unsigned int t22;
    int t23;
    int t24;
    unsigned int t25;
    int t26;
    unsigned int t27;
    unsigned int t28;
    int t29;
    int t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;
    char *t37;
    char *t38;
    char *t39;
    unsigned int t40;
    char *t41;
    unsigned int t42;
    char *t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    int t48;

LAB0:    t1 = (t0 + 3168U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(29, ng0);
    t2 = (t0 + 3488);
    *((int *)t2) = 1;
    t3 = (t0 + 3200);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(30, ng0);

LAB5:    xsi_set_current_line(31, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t0 + 1608);
    t9 = (t0 + 1608);
    t10 = (t9 + 72U);
    t11 = *((char **)t10);
    t12 = ((char*)((ng2)));
    t13 = ((char*)((ng3)));
    xsi_vlog_convert_partindices(t6, t7, t8, ((int*)(t11)), 2, t12, 32, 1, t13, 32, 1);
    t14 = (t6 + 4);
    t15 = *((unsigned int *)t14);
    t16 = (!(t15));
    t17 = (t7 + 4);
    t18 = *((unsigned int *)t17);
    t19 = (!(t18));
    t20 = (t16 && t19);
    t21 = (t8 + 4);
    t22 = *((unsigned int *)t21);
    t23 = (!(t22));
    t24 = (t20 && t23);
    if (t24 == 1)
        goto LAB6;

LAB7:    xsi_set_current_line(32, ng0);
    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    t2 = (t0 + 1608);
    t4 = (t0 + 1608);
    t5 = (t4 + 72U);
    t9 = *((char **)t5);
    t10 = ((char*)((ng4)));
    t11 = ((char*)((ng5)));
    xsi_vlog_convert_partindices(t6, t7, t8, ((int*)(t9)), 2, t10, 32, 1, t11, 32, 1);
    t12 = (t6 + 4);
    t15 = *((unsigned int *)t12);
    t16 = (!(t15));
    t13 = (t7 + 4);
    t18 = *((unsigned int *)t13);
    t19 = (!(t18));
    t20 = (t16 && t19);
    t14 = (t8 + 4);
    t22 = *((unsigned int *)t14);
    t23 = (!(t22));
    t24 = (t20 && t23);
    if (t24 == 1)
        goto LAB8;

LAB9:    xsi_set_current_line(33, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2088);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(34, ng0);
    t2 = (t0 + 1208U);
    t3 = *((char **)t2);
    memset(t6, 0, 8);
    xsi_vlog_signed_unary_minus(t6, 4, t3, 4);
    t2 = (t0 + 2248);
    xsi_vlogvar_assign_value(t2, t6, 0, 0, 4);
    xsi_set_current_line(35, ng0);
    xsi_set_current_line(35, ng0);
    t2 = ((char*)((ng5)));
    t3 = (t0 + 1928);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);

LAB10:    t2 = (t0 + 1928);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng3)));
    memset(t6, 0, 8);
    xsi_vlog_signed_less(t6, 32, t4, 32, t5, 32);
    t9 = (t6 + 4);
    t15 = *((unsigned int *)t9);
    t18 = (~(t15));
    t22 = *((unsigned int *)t6);
    t25 = (t22 & t18);
    t27 = (t25 != 0);
    if (t27 > 0)
        goto LAB11;

LAB12:    goto LAB2;

LAB6:    t25 = *((unsigned int *)t8);
    t26 = (t25 + 0);
    t27 = *((unsigned int *)t6);
    t28 = *((unsigned int *)t7);
    t29 = (t27 - t28);
    t30 = (t29 + 1);
    xsi_vlogvar_assign_value(t5, t4, t26, *((unsigned int *)t7), t30);
    goto LAB7;

LAB8:    t25 = *((unsigned int *)t8);
    t26 = (t25 + 0);
    t27 = *((unsigned int *)t6);
    t28 = *((unsigned int *)t7);
    t29 = (t27 - t28);
    t30 = (t29 + 1);
    xsi_vlogvar_assign_value(t2, t3, t26, *((unsigned int *)t7), t30);
    goto LAB9;

LAB11:    xsi_set_current_line(36, ng0);

LAB13:    xsi_set_current_line(37, ng0);
    t10 = (t0 + 2088);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    t13 = (t0 + 1048U);
    t14 = *((char **)t13);
    t13 = (t0 + 1008U);
    t17 = (t13 + 72U);
    t21 = *((char **)t17);
    t31 = (t0 + 1928);
    t32 = (t31 + 56U);
    t33 = *((char **)t32);
    xsi_vlog_generic_get_index_select_value(t8, 1, t14, t21, 2, t33, 32, 1);
    xsi_vlogtype_concat(t7, 2, 2, 2U, t8, 1, t12, 1);
    t34 = (t0 + 1768);
    xsi_vlogvar_assign_value(t34, t7, 0, 0, 2);
    xsi_set_current_line(38, ng0);
    t2 = (t0 + 1768);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);

LAB14:    t5 = ((char*)((ng6)));
    t16 = xsi_vlog_unsigned_case_compare(t4, 2, t5, 2);
    if (t16 == 1)
        goto LAB15;

LAB16:    t2 = ((char*)((ng7)));
    t16 = xsi_vlog_unsigned_case_compare(t4, 2, t2, 2);
    if (t16 == 1)
        goto LAB17;

LAB18:
LAB20:
LAB19:    xsi_set_current_line(41, ng0);

LAB26:
LAB21:    xsi_set_current_line(43, ng0);
    t2 = (t0 + 1608);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t9 = ((char*)((ng8)));
    memset(t6, 0, 8);
    xsi_vlog_signed_rshift(t6, 8, t5, 8, t9, 32);
    t10 = (t0 + 1608);
    xsi_vlogvar_assign_value(t10, t6, 0, 0, 8);
    xsi_set_current_line(45, ng0);
    t2 = (t0 + 1608);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    memset(t6, 0, 8);
    t9 = (t6 + 4);
    t10 = (t5 + 4);
    t15 = *((unsigned int *)t5);
    t18 = (t15 >> 6);
    t22 = (t18 & 1);
    *((unsigned int *)t6) = t22;
    t25 = *((unsigned int *)t10);
    t27 = (t25 >> 6);
    t28 = (t27 & 1);
    *((unsigned int *)t9) = t28;
    t11 = (t0 + 1608);
    t12 = (t0 + 1608);
    t13 = (t12 + 72U);
    t14 = *((char **)t13);
    t17 = ((char*)((ng2)));
    xsi_vlog_generic_convert_bit_index(t7, t14, 2, t17, 32, 1);
    t21 = (t7 + 4);
    t40 = *((unsigned int *)t21);
    t16 = (!(t40));
    if (t16 == 1)
        goto LAB27;

LAB28:    xsi_set_current_line(48, ng0);
    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    t2 = (t0 + 1008U);
    t5 = (t2 + 72U);
    t9 = *((char **)t5);
    t10 = (t0 + 1928);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    xsi_vlog_generic_get_index_select_value(t6, 1, t3, t9, 2, t12, 32, 1);
    t13 = (t0 + 2088);
    xsi_vlogvar_assign_value(t13, t6, 0, 0, 1);
    xsi_set_current_line(35, ng0);
    t2 = (t0 + 1928);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t9 = ((char*)((ng8)));
    memset(t6, 0, 8);
    xsi_vlog_signed_add(t6, 32, t5, 32, t9, 32);
    t10 = (t0 + 1928);
    xsi_vlogvar_assign_value(t10, t6, 0, 0, 32);
    goto LAB10;

LAB15:    xsi_set_current_line(39, ng0);
    t9 = (t0 + 1608);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    memset(t6, 0, 8);
    t12 = (t6 + 4);
    t13 = (t11 + 4);
    t15 = *((unsigned int *)t11);
    t18 = (t15 >> 4);
    *((unsigned int *)t6) = t18;
    t22 = *((unsigned int *)t13);
    t25 = (t22 >> 4);
    *((unsigned int *)t12) = t25;
    t27 = *((unsigned int *)t6);
    *((unsigned int *)t6) = (t27 & 15U);
    t28 = *((unsigned int *)t12);
    *((unsigned int *)t12) = (t28 & 15U);
    t14 = (t0 + 2248);
    t17 = (t14 + 56U);
    t21 = *((char **)t17);
    memset(t7, 0, 8);
    xsi_vlog_unsigned_add(t7, 4, t6, 4, t21, 4);
    t31 = (t0 + 1608);
    t32 = (t0 + 1608);
    t33 = (t32 + 72U);
    t34 = *((char **)t33);
    t37 = ((char*)((ng2)));
    t38 = ((char*)((ng3)));
    xsi_vlog_convert_partindices(t8, t35, t36, ((int*)(t34)), 2, t37, 32, 1, t38, 32, 1);
    t39 = (t8 + 4);
    t40 = *((unsigned int *)t39);
    t19 = (!(t40));
    t41 = (t35 + 4);
    t42 = *((unsigned int *)t41);
    t20 = (!(t42));
    t23 = (t19 && t20);
    t43 = (t36 + 4);
    t44 = *((unsigned int *)t43);
    t24 = (!(t44));
    t26 = (t23 && t24);
    if (t26 == 1)
        goto LAB22;

LAB23:    goto LAB21;

LAB17:    xsi_set_current_line(40, ng0);
    t3 = (t0 + 1608);
    t5 = (t3 + 56U);
    t9 = *((char **)t5);
    memset(t6, 0, 8);
    t10 = (t6 + 4);
    t11 = (t9 + 4);
    t15 = *((unsigned int *)t9);
    t18 = (t15 >> 4);
    *((unsigned int *)t6) = t18;
    t22 = *((unsigned int *)t11);
    t25 = (t22 >> 4);
    *((unsigned int *)t10) = t25;
    t27 = *((unsigned int *)t6);
    *((unsigned int *)t6) = (t27 & 15U);
    t28 = *((unsigned int *)t10);
    *((unsigned int *)t10) = (t28 & 15U);
    t12 = (t0 + 1208U);
    t13 = *((char **)t12);
    memset(t7, 0, 8);
    xsi_vlog_unsigned_add(t7, 4, t6, 4, t13, 4);
    t12 = (t0 + 1608);
    t14 = (t0 + 1608);
    t17 = (t14 + 72U);
    t21 = *((char **)t17);
    t31 = ((char*)((ng2)));
    t32 = ((char*)((ng3)));
    xsi_vlog_convert_partindices(t8, t35, t36, ((int*)(t21)), 2, t31, 32, 1, t32, 32, 1);
    t33 = (t8 + 4);
    t40 = *((unsigned int *)t33);
    t19 = (!(t40));
    t34 = (t35 + 4);
    t42 = *((unsigned int *)t34);
    t20 = (!(t42));
    t23 = (t19 && t20);
    t37 = (t36 + 4);
    t44 = *((unsigned int *)t37);
    t24 = (!(t44));
    t26 = (t23 && t24);
    if (t26 == 1)
        goto LAB24;

LAB25:    goto LAB21;

LAB22:    t45 = *((unsigned int *)t36);
    t29 = (t45 + 0);
    t46 = *((unsigned int *)t8);
    t47 = *((unsigned int *)t35);
    t30 = (t46 - t47);
    t48 = (t30 + 1);
    xsi_vlogvar_assign_value(t31, t7, t29, *((unsigned int *)t35), t48);
    goto LAB23;

LAB24:    t45 = *((unsigned int *)t36);
    t29 = (t45 + 0);
    t46 = *((unsigned int *)t8);
    t47 = *((unsigned int *)t35);
    t30 = (t46 - t47);
    t48 = (t30 + 1);
    xsi_vlogvar_assign_value(t12, t7, t29, *((unsigned int *)t35), t48);
    goto LAB25;

LAB27:    xsi_vlogvar_assign_value(t11, t6, 0, *((unsigned int *)t7), 1);
    goto LAB28;

}


extern void work_m_00000000000521876139_1480846789_init()
{
	static char *pe[] = {(void *)Always_29_0};
	xsi_register_didat("work_m_00000000000521876139_1480846789", "isim/tf_isim_beh.exe.sim/work/m_00000000000521876139_1480846789.didat");
	xsi_register_executes(pe);
}
